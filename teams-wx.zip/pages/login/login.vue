<template>
	<view>
		<image src="https://teams-1314238652.cos.ap-guangzhou.myqcloud.com/img/static/logo-1.png" class="logo" mode="widthFix"></image>
		<view class="logo-title">Teams在线办公协同系统</view>
		<view class="logo-subtitle">v1.0</view>
		<view><button class="login-btn" open-type="getUserInfo" @tap="login()">登陆系统</button></view>
		<view class="register-container">
			没有账号？
			<text class="register" @tap="toRegister()">立即注册</text>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {};
	},
	methods: {
		login: function() {
			let that = this;
			uni.login({
				provider: 'weixin',
				success: function(resp) {
					let code = resp.code;
					that.ajax(that.url.login, 'POST', { code }, function(resp) {
						let permission = resp.data.permission;
						uni.setStorageSync('permission', permission);
					});
					console.log('login success');
					// 跳转到展示页面
					uni.switchTab({
					    url: "../index/index"
					})
				},
				fail: function(e) {
					console.log(e);
					uni.showToast({
						icon: 'none',
						title: '执行异常'
					});
				}
			});
		},
		toRegister: function() {
			uni.navigateTo({
				url: '../register/register'
			});
		}
	}
};
</script>
<style lang="less">
@import url('login.less');
</style>
