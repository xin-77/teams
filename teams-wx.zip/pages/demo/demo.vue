<template>
	<view>
		<view>{{username}}</view>
		<view v-for="phone in tel">{{phone}}</view>
		<view v-if="age>=18">
			<button @click="signUp()">我要报名</button>
		</view>
		<view>
			<input type="text" v-model="address" placeholder="请输入地址" />
		</view>
		<view>{{address}}</view>
	</view><!-- 定义唯一根标签 -->
</template>

<script>
	export default {
		data() {
			return {
				username: '张三',
				tel: ["15265478945","18598754645"],
				age: 25,
				address:""
				
			}
		},
		methods: {
			signUp(){
				uni.showToast({
					title:"点击了报名按钮"
				})
			}
		}
	}
</script>